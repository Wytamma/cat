import{a as t}from"../chunks/entry.D3Qu2ZmB.js";export{t as start};

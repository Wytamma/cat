import{a as t}from"../chunks/entry.D9p3Q9bz.js";export{t as start};

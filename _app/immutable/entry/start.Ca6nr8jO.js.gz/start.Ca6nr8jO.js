import{a as t}from"../chunks/entry.BRbL15WI.js";export{t as start};

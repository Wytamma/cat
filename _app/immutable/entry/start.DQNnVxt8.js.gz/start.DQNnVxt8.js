import{a as t}from"../chunks/entry.Dk3AcEAA.js";export{t as start};
